#!/bin/bash

set -e


cd "$( dirname "${BASH_SOURCE[0]}" )"

CONFIG_PATH='../../../../config/postgres_db.env'

source $CONFIG_PATH

export PGPASSWORD=$NPMRDS_POSTGRES_PASSWORD


psql -h "$NPMRDS_POSTGRES_NETLOC" \
     -p "$NPMRDS_POSTGRES_PORT" \
     -U "$NPMRDS_POSTGRES_USER" \
     -d "$NPMRDS_POSTGRES_DB" \
     -f ./createRootNPMRDSDataTable.sql
