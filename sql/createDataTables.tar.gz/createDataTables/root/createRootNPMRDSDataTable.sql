DROP TABLE IF EXISTS npmrds CASCADE;

CREATE TABLE npmrds (
  tmc                            VARCHAR(9),
  date                           DATE,
  epoch                          SMALLINT,
  travel_time_all_vehicles       INT,
  travel_time_passenger_vehicles INT,
  travel_time_freight_trucks     INT,
  state                          CHAR(2)
);
