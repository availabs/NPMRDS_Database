#!/bin/bash

set -e

cd "$( dirname "${BASH_SOURCE[0]}" )"

CONFIG_PATH="../../../../config/postgres_db.env"


source $CONFIG_PATH

export PGPASSWORD=$NPMRDS_POSTGRES_PASSWORD


## FROM http://www.bahmanm.com/blogs/command-line-options-how-to-parse-in-bash-using-getopt
# read the options
TEMP=`getopt -o s: --long state: -n 'createNPMRDSDataTable.sh' -- "$@"`
eval set -- "$TEMP"

# extract options and their arguments into variables.
while true ; do
    case "$1" in
        -s|--state)
            case "$2" in
                "") shift 2 ;;
                *) STATE="${2,,}" ; shift 2 ;;
            esac ;;
        --) shift ; break ;;
        *) echo "Internal error!" ; exit 1 ;;
    esac
done

if [ -z "$STATE" ]
then
  echo "The STATE argument is required. Specify with --state=<state>"
  exit 1
fi


CREATE_DATA_TABLE_PATH='./createStateNPMRDSDataTable.sql'
CREATE_TABLE_CMD=$(sed "s/__STATE__/${STATE}/g" $CREATE_DATA_TABLE_PATH)


set +e

n=0
until [ $n -ge 10 ]
do
	[[ "$n" != 0 ]] && echo "Retry #${n}."

  psql -h $NPMRDS_POSTGRES_NETLOC \
       -p $NPMRDS_POSTGRES_PORT \
       -U $NPMRDS_POSTGRES_USER \
       -d $NPMRDS_POSTGRES_DB \
       -c "${CREATE_TABLE_CMD}" && break


  n=$[$n+1]
  sleep 2
done

set -e

if [[ "$n" -eq 10 ]]; then
	exit 1;
fi
